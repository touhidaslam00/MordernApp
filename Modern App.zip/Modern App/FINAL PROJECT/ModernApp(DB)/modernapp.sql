/*
SQLyog Community v13.1.3  (32 bit)
MySQL - 10.4.22-MariaDB : Database - modernapp
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
CREATE DATABASE /*!32312 IF NOT EXISTS*/`modernapp` /*!40100 DEFAULT CHARACTER SET utf8mb4 */;

USE `modernapp`;

/*Table structure for table `users` */

DROP TABLE IF EXISTS `users`;

CREATE TABLE `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `first_name` varchar(50) NOT NULL,
  `last_name` varchar(50) NOT NULL,
  `email` varchar(100) NOT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `profile_picture` varchar(255) DEFAULT NULL,
  `PASSWORD` varchar(255) NOT NULL,
  `newsletter` tinyint(1) DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4;

/*Data for the table `users` */

insert  into `users`(`id`,`first_name`,`last_name`,`email`,`phone`,`address`,`profile_picture`,`PASSWORD`,`newsletter`,`created_at`) values 
(6,'kabeer','aslam','kabeer00@gmail.com','03021359188',NULL,NULL,'kabeer123',1,'2026-02-26 14:47:22'),
(8,'farhan','zaheen','farhan@gmail.com','03362544124',NULL,NULL,'ZmFyaGFuMTIz',1,'2026-02-26 15:36:36'),
(10,'touhid','aslam','touhidaslam00@gmail.com','03362544124','memon mohala ward no 14 near old ubl bank shahi bazar badin','','dG91aGlkMTI=',1,'2026-02-26 18:13:33'),
(11,'kaif','aslam','kaifaslam00@gmail.com','03362544124','memon mohala ward no 14 near old ubl bank shahi bazar badin','','MTIzMTIz',1,'2026-02-26 19:11:33'),
(14,'kounain','fatima','kounain@gmail.com','+923362544124','memon mohala ward no 13','','MTIxMg==',1,'2026-02-26 22:43:32');

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
