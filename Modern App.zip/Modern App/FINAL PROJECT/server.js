const express = require("express");
const path = require("path");
const db = require('./db');
const app = express();

app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, "")));

// Root route - serve Home.html
app.get("/", (req, res) => {
    res.sendFile(path.join(__dirname, "Home.html"));
});

// Login route
app.get("/login", (req, res) => {
    res.sendFile(path.join(__dirname, "Login.html"));
});

// Register route
app.get("/register", (req, res) => {
    res.sendFile(path.join(__dirname, "Register.html"));
});

// Profile route
app.get("/profile", (req, res) => {
    res.sendFile(path.join(__dirname, "Profile.html"));
});

// Register API - accepts JSON from frontend
app.post("/api/register", (req, res) => {
    const {
        firstName, lastName, email, phone, password, newsletter
    } = req.body;

    // Encode password to base64 for storage
    const encodedPassword = Buffer.from(password).toString('base64');
    
    // Map frontend field names to database column names
    const sql = `
        INSERT INTO users 
        (first_name, last_name, email, phone, password, newsletter)
        VALUES (?, ?, ?, ?, ?, ?)
    `;

    db.query(sql, [
       firstName, lastName, email, phone, encodedPassword, newsletter ? true : false
    ], (err) => {
        if (err) {
            console.error(err);
            res.json({ success: false, message: "Error saving data: " + err.message });
        } else {
            res.json({ success: true, message: "Registered Successfully!" });
        }
    });
});

// Form Submit Route (for direct form post fallback)
app.post("/submit", (req, res) => {
    const {
        first_name, last_name, email, phone, password, newsletter
    } = req.body;

    const sql = `
        INSERT INTO users 
        (first_name, last_name, email, phone, password, newsletter)
        VALUES (?, ?, ?, ?, ?, ?)
    `;

    db.query(sql, [
       first_name, last_name, email, phone, password, newsletter
    ], (err) => {
        if (err) {
            console.error(err);
            res.send("Error saving data");
        } else {
            res.send("Registered Successfully!");
        }
    });
});

// ============================
// PROFILE API ROUTES
// ============================

// GET Profile - Get user profile by ID
app.get("/api/profile", (req, res) => {
    const userId = req.query.id;
    
    if (!userId) {
        return res.json({ success: false, message: "User ID required" });
    }
    
    const sql = "SELECT id, first_name, last_name, email, phone, address, profile_picture, newsletter, created_at FROM users WHERE id = ?";
    
    db.query(sql, [userId], (err, result) => {
        if (err) {
            console.error(err);
            return res.json({ success: false, message: "Error fetching profile: " + err.message });
        }
        
        if (result.length === 0) {
            return res.json({ success: false, message: "User not found" });
        }
        
        res.json({ success: true, user: result[0] });
    });
});

// PUT Profile - Update user profile
app.put("/api/profile", (req, res) => {
    const { id, firstName, lastName, email, phone, address, profilePicture, newsletter } = req.body;
    
    if (!id) {
        return res.json({ success: false, message: "User ID required" });
    }
    
    const sql = `
        UPDATE users 
        SET first_name = ?, last_name = ?, email = ?, phone = ?, address = ?, profile_picture = ?, newsletter = ?
        WHERE id = ?
    `;
    
    db.query(sql, [firstName, lastName, email, phone, address, profilePicture, newsletter ? true : false, id], (err) => {
        if (err) {
            console.error(err);
            return res.json({ success: false, message: "Error updating profile: " + err.message });
        }
        
        res.json({ success: true, message: "Profile updated successfully!" });
    });
});

// DELETE Profile - Delete user account
app.delete("/api/profile", (req, res) => {
    const userId = req.query.id;
    
    if (!userId) {
        return res.json({ success: false, message: "User ID required" });
    }
    
    const sql = "DELETE FROM users WHERE id = ?";
    
    db.query(sql, [userId], (err) => {
        if (err) {
            console.error(err);
            return res.json({ success: false, message: "Error deleting account: " + err.message });
        }
        
        res.json({ success: true, message: "Account deleted successfully!" });
    });
});

// POST Login - Simple login endpoint
app.post("/api/login", (req, res) => {
    const { email, password } = req.body;
    
    if (!email || !password) {
        return res.json({ success: false, message: "Email and password required" });
    }
    
    // Try both plain and base64 encoded password
    const encodedPassword = Buffer.from(password).toString('base64');
    
    const sql = "SELECT id, first_name, last_name, email, phone, address, profile_picture, newsletter, created_at FROM users WHERE email = ? AND (password = ? OR password = ?)";
    
    db.query(sql, [email, password, encodedPassword], (err, result) => {
        if (err) {
            console.error(err);
            return res.json({ success: false, message: "Error during login: " + err.message });
        }
        
        if (result.length === 0) {
            return res.json({ success: false, message: "Invalid email or password" });
        }
        
        res.json({ success: true, message: "Login successful!", user: result[0] });
    });
});

app.listen(3000, () => {
    console.log("Server running on http://localhost:3000");
});

// Migration endpoint - run once to add new columns
app.get("/api/migrate", (req, res) => {
    const addAddressColumn = "ALTER TABLE users ADD COLUMN address VARCHAR(255) AFTER phone";
    const addProfilePictureColumn = "ALTER TABLE users ADD COLUMN profile_picture VARCHAR(255) AFTER address";
    
    db.query(addAddressColumn, (err) => {
        if (err && err.code !== 'ER_DUP_FIELDNAME') {
            console.error('Error adding address column:', err);
        }
        
        db.query(addProfilePictureColumn, (err) => {
            if (err && err.code !== 'ER_DUP_FIELDNAME') {
                console.error('Error adding profile_picture column:', err);
            }
            
            res.json({ success: true, message: "Migration completed" });
        });
    });
});
