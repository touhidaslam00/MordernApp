-- MySQL Database Setup Script for ModernApp

-- Create database
CREATE DATABASE IF NOT EXISTS modernapp;
USE modernapp;

-- Create users table
CREATE TABLE IF NOT EXISTS users (
  id INT AUTO_INCREMENT PRIMARY KEY,
  first_name VARCHAR(50) NOT NULL,
  last_name VARCHAR(50) NOT NULL,
  email VARCHAR(100) NOT NULL UNIQUE,
  phone VARCHAR(20),
  address VARCHAR(255),
  profile_picture VARCHAR(255),
  password VARCHAR(255) NOT NULL,
  newsletter BOOLEAN DEFAULT FALSE,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Insert sample user (password: admin123 encoded in base64)
INSERT INTO users (first_name, last_name, email, phone, password, newsletter)
VALUES ('Admin', 'User', 'admin@example.com', '+92 300 1234-567', 'YWRtaW4xMjM=', TRUE)
ON DUPLICATE KEY UPDATE email = email;

-- Insert Kabeer user
INSERT INTO users (first_name, last_name, email, phone, password, newsletter)
VALUES ('Kabeer', 'Aslam', 'kabeeraslam00@gmail.com', '+92 300 1234-567', 'a2FiZWVyMTI=', TRUE)
ON DUPLICATE KEY UPDATE email = email;

-- Show all users
SELECT * FROM users;
